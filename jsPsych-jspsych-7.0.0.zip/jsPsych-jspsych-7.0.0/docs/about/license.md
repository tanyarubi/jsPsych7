# License

jsPsych is [licensed](https://github.com/jspsych/jsPsych/blob/main/license.txt) under the MIT license.

```
--8<-- "license.txt"
```