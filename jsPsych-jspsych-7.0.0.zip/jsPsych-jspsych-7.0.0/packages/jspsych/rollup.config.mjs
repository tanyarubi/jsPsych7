import { makeCoreRollupConfig } from "@jspsych/config/rollup";

export default makeCoreRollupConfig();
