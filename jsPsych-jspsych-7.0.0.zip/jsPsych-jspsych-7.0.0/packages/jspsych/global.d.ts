declare module "*.json"; // https://stackoverflow.com/a/61426303
