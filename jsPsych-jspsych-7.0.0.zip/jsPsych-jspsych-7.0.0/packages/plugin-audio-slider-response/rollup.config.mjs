import { makeRollupConfig } from "@jspsych/config/rollup";

export default makeRollupConfig("jsPsychAudioSliderResponse");
