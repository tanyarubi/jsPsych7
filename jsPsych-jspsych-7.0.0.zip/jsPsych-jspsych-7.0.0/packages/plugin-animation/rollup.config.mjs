import { makeRollupConfig } from "@jspsych/config/rollup";

export default makeRollupConfig("jsPsychAnimation");
