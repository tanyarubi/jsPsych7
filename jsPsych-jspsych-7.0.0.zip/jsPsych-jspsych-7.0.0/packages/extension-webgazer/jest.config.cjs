module.exports = require("@jspsych/config/jest").makePackageConfig(__dirname);
